import { useCallback, useEffect, useState } from "react";
import { ACHIEVEMENTS, CATEGORIES } from "./data";

export type Difficulty = "easy" | "normal" | "hard";

export type GameState = {
  stars: Record<string, number>; // puzzleId -> stars (1..3)
  badges: string[];
  unlockedStickers: string[];
  settings: {
    music: boolean;
    sfx: boolean;
    animations: boolean;
    difficulty: Difficulty;
  };
};

const KEY = "puzzle-macerasi-v1";

const initial: GameState = {
  stars: {},
  badges: [],
  unlockedStickers: [],
  settings: { music: false, sfx: true, animations: true, difficulty: "normal" },
};

function load(): GameState {
  if (typeof window === "undefined") return initial;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return initial;
    const parsed = JSON.parse(raw) as Partial<GameState>;
    return {
      ...initial,
      ...parsed,
      settings: { ...initial.settings, ...(parsed.settings ?? {}) },
      stars: parsed.stars ?? {},
      badges: parsed.badges ?? [],
      unlockedStickers: parsed.unlockedStickers ?? [],
    };
  } catch {
    return initial;
  }
}

export function totalStars(s: GameState) {
  return Object.values(s.stars).reduce((a, b) => a + b, 0);
}

export function completedCount(s: GameState) {
  return Object.keys(s.stars).length;
}

export function categoryProgress(s: GameState, categoryId: string) {
  const cat = CATEGORIES.find((c) => c.id === categoryId);
  if (!cat) return { done: 0, total: 0, stars: 0 };
  let done = 0;
  let stars = 0;
  for (const p of cat.puzzles) {
    const v = s.stars[p.id];
    if (v) {
      done++;
      stars += v;
    }
  }
  return { done, total: cat.puzzles.length, stars };
}

/** A puzzle is unlocked when it's the first of its category or the previous one is done. */
export function isUnlocked(s: GameState, categoryId: string, index: number) {
  if (index === 0) return true;
  const cat = CATEGORIES.find((c) => c.id === categoryId);
  if (!cat) return false;
  return Boolean(s.stars[cat.puzzles[index - 1].id]);
}

function computeBadges(s: GameState): string[] {
  const done = completedCount(s);
  const earned = new Set(s.badges);
  if (done >= 1) earned.add("first");
  if (done >= 5) earned.add("five");
  if (done >= 10) earned.add("ten");
  for (const id of ["animals", "nature", "garden", "school"]) {
    if (categoryProgress(s, id).done >= 3) earned.add(id);
  }
  if (totalStars(s) >= 50) earned.add("champion");
  return ACHIEVEMENTS.filter((a) => earned.has(a.id)).map((a) => a.id);
}

export function useGameState() {
  const [state, setState] = useState<GameState>(initial);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setState(load());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* storage unavailable */
    }
  }, [state, hydrated]);

  const recordResult = useCallback((puzzleId: string, stars: number) => {
    let newBadges: string[] = [];
    setState((prev) => {
      const best = Math.max(prev.stars[puzzleId] ?? 0, stars);
      const next: GameState = { ...prev, stars: { ...prev.stars, [puzzleId]: best } };
      const badges = computeBadges(next);
      newBadges = badges.filter((b) => !prev.badges.includes(b));
      return { ...next, badges };
    });
    return newBadges;
  }, []);

  const unlockSticker = useCallback((id: string) => {
    setState((prev) =>
      prev.unlockedStickers.includes(id)
        ? prev
        : { ...prev, unlockedStickers: [...prev.unlockedStickers, id] },
    );
  }, []);

  const setSettings = useCallback((patch: Partial<GameState["settings"]>) => {
    setState((prev) => ({ ...prev, settings: { ...prev.settings, ...patch } }));
  }, []);

  const reset = useCallback(() => setState({ ...initial, settings: initial.settings }), []);

  return { state, hydrated, recordResult, unlockSticker, setSettings, reset };
}
