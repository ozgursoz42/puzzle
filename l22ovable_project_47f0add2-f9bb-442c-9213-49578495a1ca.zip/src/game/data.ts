import animals1 from "@/assets/pz-animals-1.jpg";
import animals2 from "@/assets/pz-animals-2.jpg";
import animals3 from "@/assets/pz-animals-3.jpg";
import nature1 from "@/assets/pz-nature-1.jpg";
import nature2 from "@/assets/pz-nature-2.jpg";
import nature3 from "@/assets/pz-nature-3.jpg";
import home1 from "@/assets/pz-home-1.jpg";
import home2 from "@/assets/pz-home-2.jpg";
import school1 from "@/assets/pz-school-1.jpg";
import school2 from "@/assets/pz-school-2.jpg";
import park1 from "@/assets/pz-park-1.jpg";
import park2 from "@/assets/pz-park-2.jpg";
import garden1 from "@/assets/pz-garden-1.jpg";
import garden2 from "@/assets/pz-garden-2.jpg";

export type Puzzle = {
  id: string;
  title: string;
  image: string;
  /** grid = [cols, rows] */
  grid: [number, number];
};

export type Category = {
  id: string;
  name: string;
  emoji: string;
  color: string;
  cover: string;
  puzzles: Puzzle[];
};

const gridFor = (pieces: number): [number, number] => {
  switch (pieces) {
    case 4:
      return [2, 2];
    case 6:
      return [3, 2];
    case 9:
      return [3, 3];
    case 12:
      return [4, 3];
    case 16:
      return [4, 4];
    case 20:
      return [5, 4];
    default:
      return [5, 5];
  }
};

const mk = (id: string, title: string, image: string, pieces: number): Puzzle => ({
  id,
  title,
  image,
  grid: gridFor(pieces),
});

export const CATEGORIES: Category[] = [
  {
    id: "animals",
    name: "Sevimli Hayvanlar",
    emoji: "🐶",
    color: "sun",
    cover: animals1,
    puzzles: [
      mk("animals-1", "Kedi ve Köpek", animals1, 4),
      mk("animals-2", "Panda ve Tilki", animals2, 6),
      mk("animals-3", "Tavşan ve Kirpi", animals3, 9),
      mk("animals-4", "Kedi ve Köpek Zor", animals1, 12),
      mk("animals-5", "Panda ve Tilki Zor", animals2, 16),
      mk("animals-6", "Orman Dostları", animals3, 20),
    ],
  },
  {
    id: "nature",
    name: "Güzel Manzaralar",
    emoji: "🏞️",
    color: "sky",
    cover: nature1,
    puzzles: [
      mk("nature-1", "Dağ Gölü", nature1, 4),
      mk("nature-2", "Deniz Kenarı", nature2, 6),
      mk("nature-3", "Gün Batımı", nature3, 9),
      mk("nature-4", "Şelale", nature1, 12),
      mk("nature-5", "Palmiyeler", nature2, 16),
      mk("nature-6", "Yayla", nature3, 25),
    ],
  },
  {
    id: "home",
    name: "Ev",
    emoji: "🏡",
    color: "berry",
    cover: home1,
    puzzles: [
      mk("home-1", "Bahçeli Ev", home1, 4),
      mk("home-2", "Çocuk Odası", home2, 6),
      mk("home-3", "Sıcak Yuva", home1, 9),
      mk("home-4", "Oyuncaklı Oda", home2, 12),
      mk("home-5", "Ev ve Köpek", home1, 20),
    ],
  },
  {
    id: "school",
    name: "Okul",
    emoji: "🏫",
    color: "grape",
    cover: school1,
    puzzles: [
      mk("school-1", "Okul Binası", school1, 4),
      mk("school-2", "Sınıfımız", school2, 6),
      mk("school-3", "Okul Bahçesi", school1, 9),
      mk("school-4", "Kitaplar", school2, 12),
      mk("school-5", "Okul Zamanı", school1, 16),
    ],
  },
  {
    id: "park",
    name: "Park",
    emoji: "🛝",
    color: "leaf",
    cover: park1,
    puzzles: [
      mk("park-1", "Kaydırak", park1, 4),
      mk("park-2", "Ördek Gölü", park2, 6),
      mk("park-3", "Salıncaklar", park1, 9),
      mk("park-4", "Park Bankı", park2, 12),
      mk("park-5", "Oyun Alanı", park1, 20),
    ],
  },
  {
    id: "garden",
    name: "Güzel Bahçeler",
    emoji: "🌸",
    color: "candy",
    cover: garden1,
    puzzles: [
      mk("garden-1", "Güzel Bahçem", garden1, 4),
      mk("garden-2", "Sebze Bahçesi", garden2, 6),
      mk("garden-3", "Ayçiçekleri", garden1, 9),
      mk("garden-4", "Kulübe", garden2, 12),
      mk("garden-5", "Bahçe Yolu", garden1, 16),
      mk("garden-6", "Bahçe Ustası", garden2, 25),
    ],
  },
];

export const findCategory = (id: string) => CATEGORIES.find((c) => c.id === id);

export type Achievement = {
  id: string;
  icon: string;
  title: string;
  desc: string;
};

export const ACHIEVEMENTS: Achievement[] = [
  { id: "first", icon: "🏆", title: "İlk Puzzle", desc: "İlk puzzle'ını tamamla" },
  { id: "five", icon: "⭐", title: "5 Puzzle Tamamlandı", desc: "5 puzzle tamamla" },
  { id: "ten", icon: "🌟", title: "10 Puzzle Tamamlandı", desc: "10 puzzle tamamla" },
  { id: "animals", icon: "🐶", title: "Hayvan Dostu", desc: "3 hayvan puzzle'ı tamamla" },
  { id: "nature", icon: "🌳", title: "Doğa Kâşifi", desc: "3 manzara puzzle'ı tamamla" },
  { id: "garden", icon: "🌸", title: "Bahçe Ustası", desc: "3 bahçe puzzle'ı tamamla" },
  { id: "school", icon: "🏫", title: "Okul Kâşifi", desc: "3 okul puzzle'ı tamamla" },
  { id: "champion", icon: "🥇", title: "Puzzle Şampiyonu", desc: "50 yıldız topla" },
];

export type Sticker = { id: string; icon: string; name: string; cost: number };

export const STICKERS: Sticker[] = [
  { id: "s-bunny", icon: "🐰", name: "Tavşan", cost: 3 },
  { id: "s-puppy", icon: "🐶", name: "Köpek", cost: 6 },
  { id: "s-butterfly", icon: "🦋", name: "Kelebek", cost: 10 },
  { id: "s-flower", icon: "🌻", name: "Ayçiçeği", cost: 15 },
  { id: "s-panda", icon: "🐼", name: "Panda", cost: 22 },
  { id: "s-rainbow", icon: "🌈", name: "Gökkuşağı", cost: 30 },
];
