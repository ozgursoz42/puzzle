import type { ButtonHTMLAttributes, ReactNode } from "react";

const TONES: Record<string, string> = {
  leaf: "bg-leaf",
  sky: "bg-sky-deep",
  berry: "bg-berry",
  grape: "bg-grape",
  sun: "bg-sun-deep",
  candy: "bg-candy",
  wood: "bg-wood",
  grass: "bg-grass-deep",
};

type ToyButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  tone?: keyof typeof TONES | string;
  size?: "sm" | "md" | "lg";
  icon?: ReactNode;
};

export function ToyButton({
  tone = "leaf",
  size = "md",
  icon,
  children,
  className = "",
  ...rest
}: ToyButtonProps) {
  const sizes = {
    sm: "text-sm px-4 py-2",
    md: "text-base sm:text-lg px-5 py-2.5",
    lg: "text-lg sm:text-2xl px-6 py-3 sm:px-8 sm:py-4",
  };
  return (
    <button
      {...rest}
      className={`toy-button ${TONES[tone] ?? "bg-leaf"} ${sizes[size]} ${className}`}
    >
      {icon ? <span className="text-[1.25em] leading-none">{icon}</span> : null}
      <span className="whitespace-nowrap">{children}</span>
    </button>
  );
}

export function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      aria-label="Geri"
      className="toy-button bg-sun-deep h-12 w-12 shrink-0 p-0 text-2xl sm:h-14 sm:w-14"
    >
      ←
    </button>
  );
}

export function WoodTitle({ children }: { children: ReactNode }) {
  return (
    <div className="wood-panel min-w-0 px-4 py-2 sm:px-8 sm:py-3">
      <h1 className="font-display truncate text-lg font-extrabold tracking-wide text-cream drop-shadow-[0_2px_2px_rgba(0,0,0,0.45)] sm:text-2xl">
        {children}
      </h1>
    </div>
  );
}

export function StarBadge({ count }: { count: number }) {
  return (
    <div className="flex shrink-0 items-center gap-1.5 rounded-full border-4 border-white/80 bg-sun px-3 py-1.5 shadow-[inset_0_-4px_0_rgba(0,0,0,0.15)] sm:px-4">
      <span className="text-xl leading-none">⭐</span>
      <span className="font-display text-lg font-extrabold text-wood-dark sm:text-xl">{count}</span>
    </div>
  );
}

export function Stars({ value, max = 3, size = "text-2xl" }: { value: number; max?: number; size?: string }) {
  return (
    <div className={`flex items-center justify-center gap-0.5 ${size}`}>
      {Array.from({ length: max }).map((_, i) => (
        <span key={i} className={i < value ? "" : "opacity-25 grayscale"}>
          ⭐
        </span>
      ))}
    </div>
  );
}
