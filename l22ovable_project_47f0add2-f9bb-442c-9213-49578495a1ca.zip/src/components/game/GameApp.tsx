import { useEffect, useMemo, useState } from "react";
import { ACHIEVEMENTS, CATEGORIES, STICKERS, findCategory, type Puzzle } from "@/game/data";
import {
  categoryProgress,
  completedCount,
  isUnlocked,
  totalStars,
  useGameState,
  type Difficulty,
} from "@/game/store";
import { sfx, startMusic, stopMusic } from "@/game/sound";
import { PuzzleBoard } from "./PuzzleBoard";
import { Scenery } from "./Scenery";
import { BackButton, StarBadge, Stars, ToyButton, WoodTitle } from "./ui";

type Screen =
  | { name: "menu" }
  | { name: "categories" }
  | { name: "puzzles"; categoryId: string }
  | { name: "play"; categoryId: string; puzzleIndex: number }
  | { name: "achievements" }
  | { name: "settings" };

const DIFFICULTY_LABEL: Record<Difficulty, string> = {
  easy: "Kolay (az parça)",
  normal: "Normal",
  hard: "Zor (çok parça)",
};

function adjustGrid([cols, rows]: [number, number], d: Difficulty): [number, number] {
  if (d === "easy") return [Math.max(2, cols - 1), Math.max(2, rows - 1)];
  if (d === "hard") return [Math.min(6, cols + 1), Math.min(5, rows + 1)];
  return [cols, rows];
}

export function GameApp() {
  const { state, hydrated, recordResult, unlockSticker, setSettings } = useGameState();
  const [screen, setScreen] = useState<Screen>({ name: "menu" });
  const [result, setResult] = useState<{ stars: number; newBadges: string[] } | null>(null);
  const [round, setRound] = useState(0);

  const soundOn = state.settings.sfx;
  const animations = state.settings.animations;
  const stars = totalStars(state);

  useEffect(() => {
    if (state.settings.music) startMusic();
    else stopMusic();
    return () => stopMusic();
  }, [state.settings.music]);

  const go = (s: Screen) => {
    sfx.click(soundOn);
    setResult(null);
    setScreen(s);
  };

  const activePuzzle: { puzzle: Puzzle; cols: number; rows: number } | null = useMemo(() => {
    if (screen.name !== "play") return null;
    const cat = findCategory(screen.categoryId);
    const p = cat?.puzzles[screen.puzzleIndex];
    if (!p) return null;
    const [cols, rows] = adjustGrid(p.grid, state.settings.difficulty);
    return { puzzle: p, cols, rows };
  }, [screen, state.settings.difficulty]);

  if (!hydrated) {
    return (
      <main className="grid min-h-screen place-items-center">
        <Scenery animations={false} />
        <div className="cream-panel px-8 py-6 font-display text-2xl text-wood-dark">
          Yükleniyor… 🧩
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen px-3 py-4 sm:px-6 sm:py-6">
      <Scenery animations={animations} />

      {screen.name === "menu" && <Menu stars={stars} onGo={go} state={state} />}

      {screen.name === "categories" && (
        <Categories
          stars={stars}
          onBack={() => go({ name: "menu" })}
          onPick={(id) => go({ name: "puzzles", categoryId: id })}
          progressOf={(id) => categoryProgress(state, id)}
        />
      )}

      {screen.name === "puzzles" && (
        <PuzzleList
          categoryId={screen.categoryId}
          stars={stars}
          starsOf={(pid) => state.stars[pid] ?? 0}
          unlocked={(i) => isUnlocked(state, screen.categoryId, i)}
          onBack={() => go({ name: "categories" })}
          onPick={(i) => {
            setRound((r) => r + 1);
            go({ name: "play", categoryId: screen.categoryId, puzzleIndex: i });
          }}
        />
      )}

      {screen.name === "play" && activePuzzle && (
        <PlayScreen
          key={`${activePuzzle.puzzle.id}-${round}`}
          categoryId={screen.categoryId}
          puzzleIndex={screen.puzzleIndex}
          puzzle={activePuzzle.puzzle}
          cols={activePuzzle.cols}
          rows={activePuzzle.rows}
          stars={stars}
          animations={animations}
          soundOn={soundOn}
          result={result}
          onBack={() => go({ name: "puzzles", categoryId: screen.categoryId })}
          onComplete={(s) => {
            const newBadges = recordResult(activePuzzle.puzzle.id, s);
            if (newBadges.length) sfx.badge(soundOn);
            setResult({ stars: s, newBadges });
          }}
          onReplay={() => {
            sfx.click(soundOn);
            setResult(null);
            setRound((r) => r + 1);
          }}
          onNext={() => {
            const cat = findCategory(screen.categoryId);
            const next = screen.puzzleIndex + 1;
            if (cat && next < cat.puzzles.length) {
              setRound((r) => r + 1);
              go({ name: "play", categoryId: screen.categoryId, puzzleIndex: next });
            } else {
              go({ name: "puzzles", categoryId: screen.categoryId });
            }
          }}
        />
      )}

      {screen.name === "achievements" && (
        <Achievements
          stars={stars}
          badges={state.badges}
          done={completedCount(state)}
          unlockedStickers={state.unlockedStickers}
          onUnlock={(id) => {
            sfx.badge(soundOn);
            unlockSticker(id);
          }}
          onBack={() => go({ name: "menu" })}
        />
      )}

      {screen.name === "settings" && (
        <Settings
          stars={stars}
          settings={state.settings}
          onChange={(patch) => {
            sfx.click(soundOn);
            setSettings(patch);
          }}
          onBack={() => go({ name: "menu" })}
        />
      )}
    </main>
  );
}

/* ---------------- Screens ---------------- */

function TopBar({
  title,
  stars,
  onBack,
}: {
  title: string;
  stars: number;
  onBack?: () => void;
}) {
  return (
    <header className="mx-auto mb-4 grid max-w-6xl grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 sm:gap-4">
      {onBack ? <BackButton onClick={onBack} /> : <span />}
      <div className="flex min-w-0 justify-center">
        <WoodTitle>{title}</WoodTitle>
      </div>
      <StarBadge count={stars} />
    </header>
  );
}

function Menu({
  stars,
  onGo,
  state,
}: {
  stars: number;
  onGo: (s: Screen) => void;
  state: ReturnType<typeof useGameState>["state"];
}) {
  return (
    <div className="mx-auto flex max-w-3xl flex-col items-center gap-6 py-4 text-center">
      <div className="flex w-full justify-end">
        <StarBadge count={stars} />
      </div>

      <div className="wood-panel animate-pop-in px-5 py-4 sm:px-10 sm:py-6">
        <p className="font-display text-sm font-extrabold uppercase tracking-widest text-cream/90 sm:text-base">
          Çocuklar için
        </p>
        <h1 className="font-display text-4xl font-extrabold leading-none text-cream drop-shadow-[0_4px_0_rgba(0,0,0,0.35)] sm:text-6xl">
          PUZZLE
        </h1>
        <h2 className="font-display text-2xl font-extrabold tracking-wide text-sun drop-shadow-[0_3px_0_rgba(0,0,0,0.35)] sm:text-4xl">
          MACERASI
        </h2>
      </div>

      <div className="grid w-full max-w-sm gap-3 sm:max-w-md">
        <ToyButton tone="leaf" size="lg" icon="▶️" onClick={() => onGo({ name: "categories" })}>
          OYNA
        </ToyButton>
        <ToyButton tone="sky" size="lg" icon="🧩" onClick={() => onGo({ name: "categories" })}>
          BÖLÜMLER
        </ToyButton>
        <ToyButton tone="berry" size="lg" icon="⭐" onClick={() => onGo({ name: "achievements" })}>
          KAZANIMLAR
        </ToyButton>
        <ToyButton tone="grape" size="lg" icon="⚙️" onClick={() => onGo({ name: "settings" })}>
          AYARLAR
        </ToyButton>
      </div>

      <div className="cream-panel flex max-w-md items-center gap-3 px-4 py-3 text-left">
        <span className="text-4xl">🦔</span>
        <p className="font-display text-sm font-bold text-wood-dark sm:text-base">
          Parçaları doğru yere sürükle, resmi tamamla! Şu ana kadar{" "}
          {completedCount(state)} puzzle bitirdin.
        </p>
      </div>
    </div>
  );
}

function Categories({
  stars,
  onBack,
  onPick,
  progressOf,
}: {
  stars: number;
  onBack: () => void;
  onPick: (id: string) => void;
  progressOf: (id: string) => { done: number; total: number; stars: number };
}) {
  return (
    <div className="mx-auto max-w-6xl">
      <TopBar title="BÖLÜMLER" stars={stars} onBack={onBack} />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {CATEGORIES.map((c) => {
          const p = progressOf(c.id);
          return (
            <button
              key={c.id}
              onClick={() => onPick(c.id)}
              className="wood-panel group p-2 text-left transition-transform hover:-translate-y-1 active:translate-y-0.5"
            >
              <div className="overflow-hidden rounded-xl border-2 border-cream">
                <img
                  src={c.cover}
                  alt={c.name}
                  loading="lazy"
                  width={1024}
                  height={768}
                  className="h-32 w-full object-cover transition-transform duration-300 group-hover:scale-105 sm:h-40"
                />
              </div>
              <div className="mt-2 rounded-xl bg-cream px-3 py-2">
                <div className="flex min-w-0 items-center gap-2">
                  <span className="shrink-0 text-2xl">{c.emoji}</span>
                  <span className="font-display truncate text-base font-extrabold uppercase text-wood-dark sm:text-lg">
                    {c.name}
                  </span>
                </div>
                <div className="mt-1 flex items-center justify-between">
                  <span className="font-display text-sm font-bold text-wood">
                    {p.done} / {p.total}
                  </span>
                  <span className="text-base">
                    {"⭐".repeat(Math.min(3, Math.ceil(p.stars / 3))) || "☆"}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function PuzzleList({
  categoryId,
  stars,
  starsOf,
  unlocked,
  onBack,
  onPick,
}: {
  categoryId: string;
  stars: number;
  starsOf: (id: string) => number;
  unlocked: (i: number) => boolean;
  onBack: () => void;
  onPick: (i: number) => void;
}) {
  const cat = findCategory(categoryId);
  if (!cat) return null;
  return (
    <div className="mx-auto max-w-6xl">
      <TopBar title={cat.name.toUpperCase()} stars={stars} onBack={onBack} />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {cat.puzzles.map((p, i) => {
          const open = unlocked(i);
          const s = starsOf(p.id);
          return (
            <button
              key={p.id}
              disabled={!open}
              onClick={() => onPick(i)}
              className={`wood-panel p-2 text-left transition-transform ${
                open ? "hover:-translate-y-1 active:translate-y-0.5" : "opacity-70"
              }`}
            >
              <div className="relative overflow-hidden rounded-xl border-2 border-cream">
                <img
                  src={p.image}
                  alt={p.title}
                  loading="lazy"
                  width={1024}
                  height={768}
                  className={`h-24 w-full object-cover sm:h-32 ${open ? "" : "grayscale"}`}
                />
                {!open ? (
                  <div className="absolute inset-0 grid place-items-center bg-wood-dark/55 text-3xl">
                    🔒
                  </div>
                ) : null}
              </div>
              <div className="mt-2 rounded-xl bg-cream px-2 py-1.5">
                <div className="font-display truncate text-sm font-extrabold text-wood-dark sm:text-base">
                  {p.title}
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-display text-xs font-bold text-wood">
                    {p.grid[0] * p.grid[1]} parça
                  </span>
                  <Stars value={s} size="text-sm" />
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Confetti() {
  const bits = Array.from({ length: 40 }, (_, i) => i);
  const colors = ["#ffd23f", "#ff6f91", "#4ec3f7", "#7bd66c", "#b98cf0", "#ff9f45"];
  return (
    <div className="pointer-events-none fixed inset-0 z-40 overflow-hidden">
      {bits.map((i) => (
        <span
          key={i}
          className="absolute block h-3 w-2 rounded-sm"
          style={{
            left: `${(i * 2.5) % 100}%`,
            backgroundColor: colors[i % colors.length],
            animation: `confetti-fall ${2 + (i % 5) * 0.4}s linear ${(i % 10) * 0.15}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

function PlayScreen({
  categoryId,
  puzzleIndex,
  puzzle,
  cols,
  rows,
  stars,
  animations,
  soundOn,
  result,
  onBack,
  onComplete,
  onReplay,
  onNext,
}: {
  categoryId: string;
  puzzleIndex: number;
  puzzle: Puzzle;
  cols: number;
  rows: number;
  stars: number;
  animations: boolean;
  soundOn: boolean;
  result: { stars: number; newBadges: string[] } | null;
  onBack: () => void;
  onComplete: (stars: number) => void;
  onReplay: () => void;
  onNext: () => void;
}) {
  const cat = findCategory(categoryId);
  const hasNext = Boolean(cat && puzzleIndex + 1 < cat.puzzles.length);
  return (
    <div className="mx-auto max-w-6xl">
      <TopBar title={puzzle.title.toUpperCase()} stars={stars} onBack={onBack} />
      <PuzzleBoard
        puzzle={puzzle}
        cols={cols}
        rows={rows}
        animations={animations}
        soundOn={soundOn}
        onComplete={onComplete}
      />

      {result ? (
        <>
          {animations ? <Confetti /> : null}
          <div className="fixed inset-0 z-40 grid place-items-center bg-wood-dark/50 p-4">
            <div className="cream-panel animate-pop-in w-full max-w-md p-4 text-center sm:p-6">
              <img
                src={puzzle.image}
                alt={puzzle.title}
                width={1024}
                height={768}
                className="mx-auto h-36 w-full rounded-2xl border-4 border-wood object-cover sm:h-48"
              />
              <h2 className="font-display mt-3 text-4xl font-extrabold text-berry drop-shadow-[0_3px_0_rgba(0,0,0,0.15)] sm:text-5xl">
                HARİKA!
              </h2>
              <p className="font-display text-lg font-bold text-wood-dark">Resmi tamamladın!</p>
              <div className={animations ? "animate-pop-in" : ""}>
                <Stars value={result.stars} size="text-4xl sm:text-5xl" />
              </div>
              {result.newBadges.length ? (
                <p className="font-display mt-1 text-sm font-bold text-grape">
                  Yeni rozet kazandın! 🏆
                </p>
              ) : null}
              <div className="mt-4 grid gap-2 sm:grid-cols-3">
                <ToyButton tone="sun" size="sm" icon="🔁" onClick={onReplay}>
                  TEKRAR
                </ToyButton>
                <ToyButton tone="leaf" size="sm" icon="➡️" onClick={onNext} disabled={!hasNext}>
                  SONRAKİ
                </ToyButton>
                <ToyButton tone="sky" size="sm" icon="🧩" onClick={onBack}>
                  BÖLÜMLER
                </ToyButton>
              </div>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}

function Achievements({
  stars,
  badges,
  done,
  unlockedStickers,
  onUnlock,
  onBack,
}: {
  stars: number;
  badges: string[];
  done: number;
  unlockedStickers: string[];
  onUnlock: (id: string) => void;
  onBack: () => void;
}) {
  return (
    <div className="mx-auto max-w-5xl">
      <TopBar title="KAZANIMLAR" stars={stars} onBack={onBack} />

      <div className="cream-panel mb-4 px-4 py-3 text-center font-display text-base font-extrabold text-wood-dark sm:text-lg">
        {done} puzzle tamamlandı · {stars} yıldız toplandı
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {ACHIEVEMENTS.map((a) => {
          const earned = badges.includes(a.id);
          return (
            <div
              key={a.id}
              className={`cream-panel p-3 text-center ${earned ? "" : "opacity-60 grayscale"}`}
            >
              <div className="text-4xl">{a.icon}</div>
              <div className="font-display text-sm font-extrabold text-wood-dark sm:text-base">
                {a.title}
              </div>
              <div className="text-xs font-bold text-wood">{earned ? "Kazanıldı!" : a.desc}</div>
            </div>
          );
        })}
      </div>

      <h3 className="font-display mt-6 text-center text-xl font-extrabold text-cream drop-shadow-[0_2px_2px_rgba(0,0,0,0.5)] sm:text-2xl">
        ÇIKARTMA DÜKKANI
      </h3>
      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {STICKERS.map((s) => {
          const owned = unlockedStickers.includes(s.id);
          const affordable = stars >= s.cost;
          return (
            <div key={s.id} className="cream-panel p-3 text-center">
              <div className={`text-4xl ${owned ? "" : "grayscale opacity-60"}`}>{s.icon}</div>
              <div className="font-display text-sm font-extrabold text-wood-dark">{s.name}</div>
              {owned ? (
                <div className="font-display text-xs font-bold text-leaf">AÇILDI ✓</div>
              ) : (
                <ToyButton
                  tone={affordable ? "sun" : "wood"}
                  size="sm"
                  className="mt-1 w-full"
                  disabled={!affordable}
                  onClick={() => onUnlock(s.id)}
                >
                  ⭐ {s.cost}
                </ToyButton>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Toggle({
  label,
  icon,
  value,
  onToggle,
}: {
  label: string;
  icon: string;
  value: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="cream-panel flex items-center justify-between gap-3 px-4 py-3">
      <span className="font-display flex min-w-0 items-center gap-2 text-base font-extrabold text-wood-dark sm:text-lg">
        <span className="text-2xl">{icon}</span>
        <span className="truncate">{label}</span>
      </span>
      <ToyButton tone={value ? "leaf" : "berry"} size="sm" onClick={onToggle}>
        {value ? "AÇIK" : "KAPALI"}
      </ToyButton>
    </div>
  );
}

function Settings({
  stars,
  settings,
  onChange,
  onBack,
}: {
  stars: number;
  settings: { music: boolean; sfx: boolean; animations: boolean; difficulty: Difficulty };
  onChange: (p: Partial<typeof settings>) => void;
  onBack: () => void;
}) {
  return (
    <div className="mx-auto max-w-2xl">
      <TopBar title="AYARLAR" stars={stars} onBack={onBack} />
      <div className="grid gap-3">
        <Toggle
          label="Müzik"
          icon="🎵"
          value={settings.music}
          onToggle={() => onChange({ music: !settings.music })}
        />
        <Toggle
          label="Ses Efektleri"
          icon="🔊"
          value={settings.sfx}
          onToggle={() => onChange({ sfx: !settings.sfx })}
        />
        <Toggle
          label="Animasyonlar"
          icon="✨"
          value={settings.animations}
          onToggle={() => onChange({ animations: !settings.animations })}
        />
        <div className="cream-panel px-4 py-3">
          <div className="font-display mb-2 flex items-center gap-2 text-base font-extrabold text-wood-dark sm:text-lg">
            <span className="text-2xl">🧩</span> Zorluk Seviyesi
          </div>
          <div className="grid gap-2 sm:grid-cols-3">
            {(["easy", "normal", "hard"] as Difficulty[]).map((d) => (
              <ToyButton
                key={d}
                tone={settings.difficulty === d ? "leaf" : "wood"}
                size="sm"
                onClick={() => onChange({ difficulty: d })}
              >
                {DIFFICULTY_LABEL[d]}
              </ToyButton>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
