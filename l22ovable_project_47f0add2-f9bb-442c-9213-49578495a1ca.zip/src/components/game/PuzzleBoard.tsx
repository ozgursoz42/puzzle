import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Puzzle } from "@/game/data";
import { sfx } from "@/game/sound";
import { ToyButton } from "./ui";

type Props = {
  puzzle: Puzzle;
  cols: number;
  rows: number;
  animations: boolean;
  soundOn: boolean;
  onComplete: (stars: number) => void;
};

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function pieceStyle(image: string, index: number, cols: number, rows: number) {
  const col = index % cols;
  const row = Math.floor(index / cols);
  return {
    backgroundImage: `url(${image})`,
    backgroundSize: `${cols * 100}% ${rows * 100}%`,
    backgroundPosition: `${cols > 1 ? (col / (cols - 1)) * 100 : 0}% ${
      rows > 1 ? (row / (rows - 1)) * 100 : 0
    }%`,
  };
}

export function PuzzleBoard({ puzzle, cols, rows, animations, soundOn, onComplete }: Props) {
  const total = cols * rows;
  const boardRef = useRef<HTMLDivElement>(null);
  const [placed, setPlaced] = useState<boolean[]>(() => Array(total).fill(false));
  const [tray, setTray] = useState<number[]>(() => shuffle(Array.from({ length: total }, (_, i) => i)));
  const [drag, setDrag] = useState<{ index: number; x: number; y: number } | null>(null);
  const [wrongIndex, setWrongIndex] = useState<number | null>(null);
  const [sparkCell, setSparkCell] = useState<number | null>(null);
  const [mistakes, setMistakes] = useState(0);
  const [hint, setHint] = useState(false);
  const [hintsLeft, setHintsLeft] = useState(3);
  const [cellSize, setCellSize] = useState({ w: 80, h: 60 });
  const doneRef = useRef(false);

  // reset when puzzle changes
  useEffect(() => {
    setPlaced(Array(total).fill(false));
    setTray(shuffle(Array.from({ length: total }, (_, i) => i)));
    setMistakes(0);
    setHintsLeft(3);
    setHint(false);
    doneRef.current = false;
  }, [puzzle.id, total]);

  const measure = useCallback(() => {
    const el = boardRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setCellSize({ w: r.width / cols, h: r.height / rows });
  }, [cols, rows]);

  useEffect(() => {
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [measure]);

  const placedCount = placed.filter(Boolean).length;

  const finish = useCallback(
    (missCount: number) => {
      if (doneRef.current) return;
      doneRef.current = true;
      const stars = missCount <= 1 ? 3 : missCount <= 4 ? 2 : 1;
      sfx.win(soundOn);
      setTimeout(() => onComplete(stars), 650);
    },
    [onComplete, soundOn],
  );

  const dropAt = useCallback(
    (index: number, clientX: number, clientY: number) => {
      const el = boardRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const inside =
        clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom;
      const col = Math.floor(((clientX - r.left) / r.width) * cols);
      const row = Math.floor(((clientY - r.top) / r.height) * rows);
      const cell = row * cols + col;

      if (inside && cell === index) {
        sfx.correct(soundOn);
        setSparkCell(index);
        setTimeout(() => setSparkCell(null), 650);
        setPlaced((p) => {
          const next = [...p];
          next[index] = true;
          if (next.every(Boolean)) finish(mistakes);
          return next;
        });
        setTray((t) => t.filter((i) => i !== index));
      } else {
        sfx.wrong(soundOn);
        setMistakes((m) => m + 1);
        setWrongIndex(index);
        setTimeout(() => setWrongIndex(null), 400);
      }
    },
    [cols, rows, soundOn, mistakes, finish],
  );

  const startDrag = (index: number) => (e: React.PointerEvent) => {
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    measure();
    setDrag({ index, x: e.clientX, y: e.clientY });
  };

  const onMove = (e: React.PointerEvent) => {
    if (!drag) return;
    e.preventDefault();
    setDrag({ ...drag, x: e.clientX, y: e.clientY });
  };

  const onUp = (e: React.PointerEvent) => {
    if (!drag) return;
    const d = drag;
    setDrag(null);
    dropAt(d.index, e.clientX, e.clientY);
  };

  const useHint = () => {
    if (hintsLeft <= 0) return;
    sfx.click(soundOn);
    setHintsLeft((h) => h - 1);
    setHint(true);
    setTimeout(() => setHint(false), 2200);
  };

  const cells = useMemo(() => Array.from({ length: total }, (_, i) => i), [total]);

  return (
    <div
      className="flex w-full flex-col gap-3 lg:flex-row lg:items-start lg:gap-5"
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={() => setDrag(null)}
    >
      {/* Board */}
      <div className="wood-panel min-w-0 flex-1 p-2 sm:p-3">
        <div
          ref={boardRef}
          className="relative w-full overflow-hidden rounded-xl bg-cream"
          style={{ aspectRatio: `${cols * 4} / ${rows * 3}` }}
        >
          {hint ? (
            <img
              src={puzzle.image}
              alt=""
              className="pointer-events-none absolute inset-0 h-full w-full object-fill opacity-35"
            />
          ) : null}
          <div
            className="absolute inset-0 grid"
            style={{
              gridTemplateColumns: `repeat(${cols}, 1fr)`,
              gridTemplateRows: `repeat(${rows}, 1fr)`,
            }}
          >
            {cells.map((i) => (
              <div
                key={i}
                className="relative border border-dashed border-wood/35 bg-cream/70"
              >
                {placed[i] ? (
                  <div
                    className={`absolute inset-0 bg-no-repeat ${animations ? "animate-pop-in" : ""}`}
                    style={pieceStyle(puzzle.image, i, cols, rows)}
                  />
                ) : null}
                {sparkCell === i && animations ? (
                  <span
                    className="pointer-events-none absolute inset-0 grid place-items-center text-3xl"
                    style={{ animation: "sparkle 0.65s ease-out both" }}
                  >
                    ✨
                  </span>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tray */}
      <div className="wood-panel w-full shrink-0 p-2 sm:p-3 lg:w-56">
        <div className="mb-2 text-center font-display text-sm font-extrabold text-cream drop-shadow sm:text-base">
          PARÇALAR · {tray.length}
        </div>
        <div className="flex max-h-40 flex-wrap justify-center gap-2 overflow-y-auto rounded-xl bg-wood-dark/30 p-2 lg:max-h-[26rem]">
          {tray.map((i) => (
            <div
              key={i}
              role="button"
              tabIndex={0}
              aria-label={`Parça ${i + 1}`}
              onPointerDown={startDrag(i)}
              className={`h-14 w-16 shrink-0 cursor-grab touch-none rounded-lg border-2 border-cream bg-no-repeat shadow-md transition-transform hover:scale-105 active:cursor-grabbing sm:h-16 sm:w-20 ${
                drag?.index === i ? "opacity-30" : ""
              } ${wrongIndex === i && animations ? "animate-shake-x" : ""}`}
              style={pieceStyle(puzzle.image, i, cols, rows)}
            />
          ))}
          {tray.length === 0 ? (
            <div className="p-3 text-center font-display text-cream">Hepsi yerleşti! 🎉</div>
          ) : null}
        </div>

        <div className="mt-3 flex items-center justify-between gap-2">
          <ToyButton tone="grass" size="sm" icon="💡" onClick={useHint} disabled={hintsLeft === 0}>
            İPUCU {hintsLeft}
          </ToyButton>
          <div className="rounded-full border-4 border-white/80 bg-sun-deep px-3 py-1 font-display text-sm font-extrabold text-white">
            {placedCount}/{total}
          </div>
        </div>
      </div>

      {/* Floating dragged piece */}
      {drag ? (
        <div
          className="pointer-events-none fixed z-50 rounded-lg border-2 border-cream bg-no-repeat shadow-2xl"
          style={{
            ...pieceStyle(puzzle.image, drag.index, cols, rows),
            width: cellSize.w,
            height: cellSize.h,
            left: drag.x - cellSize.w / 2,
            top: drag.y - cellSize.h / 2,
            transform: "scale(1.05) rotate(-2deg)",
          }}
        />
      ) : null}
    </div>
  );
}
